'''
Final Project
Author: Nabeen Neupane
Date: 7/28/2022
'''

# Imports the packages

import tkinter as tk

from tkinter import *

from tkinter import messagebox

from PIL import ImageTk, Image

# Creates the root window

root = tk.Tk()

root.minsize(700, 500)  # Sets the size of the window

root.title("PP Palace")  # Title of the window

# Opens the first image file

image1 = Image.open("C:\\Users\\Nabeen Neupane\\Pictures\\pizza-slice-diane-diederich.jpg")

# Resizes the image

image1 = image1.resize((150, 150))

test = ImageTk.PhotoImage(image1)

# Opens the second image file

image2 = Image.open("C:\\Users\\Nabeen Neupane\\Pictures\\image.jpg")

# Resizes the image

image2 = image2.resize((150, 150))

test2 = ImageTk.PhotoImage(image2)

# Setting the first image in label l3

l3 = tk.Label(root, image=test)

l3.place(x=50, y=10)  # Positions the label

# Setting the second image in label l4

l4 = tk.Label(root, image=test2)

l4.place(x=350, y=10)  # Positions the label

# Displays a menu for pizza using a label with font and size of text

l5 = tk.Label(root, text="Pizza: Cheese pizza, Pepperoni pizza, Veggie pizza, Chicken pizza, Supreme pizza",
              font=("Arial", 15))

l5.place(x=50, y=200)

# Displays a menu for drinks

l6 = tk.Label(root, text="Drinks: Water, Sprite, Fanta, Coke, Pepsi", font=("Arial", 15))

l6.place(x=50, y=230)

l1 = tk.Label(root, text="Please choose a pizza: ", font=("Arial", 15))

l1.place(x=50, y=280)  # The position of the entry box

# Entry box with font and size

t1 = tk.Entry(root, font=("Arial", 15))

t1.place(x=380, y=280)  # Position of the entry box

l2 = tk.Label(root, text="Please choose a drink: ", font=("Arial", 15))

l2.place(x=50, y=310)

t2 = tk.Entry(root, font=("Arial", 15))

t2.place(x=380, y=310)


# Function to calculate price of pizza and drink separately

def calc():
    s1 = t1.get()  # Takes all contents from the first entry

    s2 = t2.get()  # Takes all contents from the second entry

    pizza = s1.split(sep=',')  # Separates each item from s1

    drinks = s2.split(sep=',')  # Separates each item from s2

    len1 = len(pizza)  # Finding the number of items or pizza

    len2 = len(drinks)  # Finding the number of items or drinks

    priceOfPizza = len1 * 8.99  # Multiplies number of pizza with price of 1

    priceOfDrinks = len2 * 1.99  # Multiplies number of drinks with price of 1

    # Displays message box

    s = 'Price of pizza : {} Price of drinks : {}'.format(priceOfPizza, priceOfDrinks)

    messagebox.showinfo('Price of pizza and drinks', s)

    # Returns price of pizza and drinks including list of pizza names and list of drink names

    return priceOfPizza, priceOfDrinks, pizza, drinks


def displaytotal():
    pr_pizza, pr_drinks, pizza, drinks = calc()
    totalp = pr_pizza + pr_drinks  # Finds the total price
    s = 'Total price : %.2f'%totalp
    messagebox.showinfo('Total price',s)


def total():
    # Collects the price of pizzas, drinks, and names of pizzas and drinks

    pr_pizza, pr_drinks, pizza, drinks = calc()

    total = pr_pizza + pr_drinks  # Finds the total price

    s = 'Total price : {:5.2f}'.format(total)

    child_w = Toplevel(root)  # Creates another window

    child_w.geometry("350x350")  # The size of the child window

    child_w.grid_location(x=300, y=300)  # The location of the child window

    child_w.title("The Total Price")  # The title of the window

    # Creates label widgets

    label_child = Label(child_w, text=s, font=('Helvetica 15'))

    label_child.place(x=20, y=50)  # Positions the label

    l2 = Label(child_w, text="You have ordered", font=('Helvetica 15'))

    l2.place(x=20, y=100)  # Positions the label

    s2 = ' '.join(pizza) + " " + ' '.join(drinks)

    l3 = Label(child_w, text=s2, font=('Helvetica 15'))

    l3.place(x=20, y=150)  # Positions the label

    # Creating buttons

    # Click this button to calculate the price of pizza and drinks separately

    b1 = tk.Button(root, text="Calculate price of pizza and drink", command=calc, font=("Arial", 15))

    b1.place(x=100, y=380)

    # Click this button to calculate total price of pizza and drinks

    b2 = tk.Button(root, text="Calculate total price", command=displaytotal, font=("Arial", 15))

    b2.place(x=100, y=420)

    # Click this button to exit the program

    b3 = tk.Button(root, text="Exit", command=root.destroy, font=("Arial", 15))

    b3.place(x=100, y=460)

    # Starts the main window

    root.mainloop()


total()